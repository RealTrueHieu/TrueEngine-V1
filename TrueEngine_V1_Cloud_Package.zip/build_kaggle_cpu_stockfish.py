import json
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
NB_DIR = os.path.join(BASE_DIR, "kaggle_cpu_stockfish")
os.makedirs(NB_DIR, exist_ok=True)
NB_PATH = os.path.join(NB_DIR, "notebookb848d05196.ipynb")
META_PATH = os.path.join(NB_DIR, "kernel-metadata.json")

# Read tunnel token
tunnel_token = None
cfg_path = os.path.join(BASE_DIR, "kaggle_tunnel_config.json")
if os.path.exists(cfg_path):
    with open(cfg_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
        tunnel_token = cfg.get("tunnel_token")

if not tunnel_token:
    tunnel_token = "eyJhIjoiMzViY2IyMGEzZDY1NWYyZDNkZTdmZDdhMzk1OTdlY2QiLCJ0IjoiY2Q0NjMzNTktNDJlYy00ZjRmLWE2ZTUtYWY1OWE4NGY1MDQ0IiwicyI6ImxTeDZFcDBYb2lkUmJ6bUdBQ3NEWEVWTzQ1TW1jdE11NnB6VUxoTTYzN1E9In0="

# Metadata
metadata = {
    "id": "trantrungminhhieu/notebookb848d05196",
    "title": "notebookb848d05196",
    "code_file": "notebookb848d05196.ipynb",
    "language": "python",
    "kernel_type": "notebook",
    "is_private": True,
    "enable_gpu": False,
    "enable_tpu": False,
    "enable_internet": True,
    "keywords": [],
    "dataset_sources": [],
    "kernel_sources": [],
    "competition_sources": [],
    "model_sources": []
}

with open(META_PATH, "w", encoding="utf-8") as f:
    json.dump(metadata, f, indent=2)

# CELL 0: Header
cell_0 = {
    "cell_type": "markdown",
    "metadata": {},
    "source": [
        "# ♟️ TrueEngine Stockfish 19 High-Performance CPU Supercomputing Server\n",
        "- **Hardware:** 4x Intel Xeon vCPUs, 30GB System RAM (Unlimited CPU Quota, 0 Queue Wait)\n",
        "- **Engine:** Official Stockfish 19 Linux x86-64 with Embedded NNUE Architecture\n",
        "- **Configuration:** 4 Threads, 2048 MB Hash, High Tactical Pruning (Depth 45 - 55+)\n",
        "- **Tunneling:** Cloudflare Tunnel via `https://kaggle.truehieu.qzz.io`"
    ]
}

# CELL 1: Download Stockfish 19 & Cloudflared in pure Python
cell_1_code = r'''import os, sys, subprocess, time, tarfile, urllib.request

print("📦 1. Installing required Python packages...", flush=True)
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "fastapi", "uvicorn", "python-chess", "requests"], check=True)

print("⬇️ 2. Downloading cloudflared Linux binary...", flush=True)
cf_bin = "/usr/local/bin/cloudflared"
if not os.path.exists(cf_bin):
    req = urllib.request.Request(
        "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
        headers={"User-Agent": "Mozilla/5.0"}
    )
    with urllib.request.urlopen(req) as resp, open(cf_bin, "wb") as f:
        f.write(resp.read())
    os.chmod(cf_bin, 0o755)
print("✅ cloudflared ready at:", cf_bin, flush=True)

print("⬇️ 3. Downloading official Stockfish 19 Linux binary...", flush=True)
os.makedirs("/tmp/sf19", exist_ok=True)
sf_tar = "/tmp/sf19/sf19.tar.gz"
req_sf = urllib.request.Request(
    "https://github.com/official-stockfish/Stockfish/releases/download/sf_19/stockfish-linux-x86-64-universal.tar.gz",
    headers={"User-Agent": "Mozilla/5.0"}
)
with urllib.request.urlopen(req_sf) as resp, open(sf_tar, "wb") as f:
    f.write(resp.read())

print("📦 4. Extracting Stockfish 19 archive...", flush=True)
with tarfile.open(sf_tar, "r:gz") as tar:
    tar.extractall("/tmp/sf19")

sf_bin = None
for root, dirs, files in os.walk("/tmp/sf19"):
    for f in files:
        if f.startswith("stockfish") and not f.endswith((".tar", ".gz", ".txt", ".md", ".sh", ".h", ".cpp")):
            cand = os.path.join(root, f)
            os.chmod(cand, 0o755)
            sf_bin = cand
            break
    if sf_bin:
        break

print("✅ Official Stockfish 19 binary ready at:", sf_bin, flush=True)
with open("/tmp/sf_bin_path.txt", "w") as f:
    f.write(sf_bin or "/usr/games/stockfish")
'''

cell_1 = {
    "cell_type": "code",
    "execution_count": None,
    "metadata": {},
    "outputs": [],
    "source": [line + "\n" for line in cell_1_code.strip().split("\n")]
}

# CELL 2: Write Stockfish FastAPI Server
server_code = r'''import os, sys, subprocess, threading, time, re, json
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn, chess

app = FastAPI(title="TrueEngine Stockfish 19 CPU Supercomputing Server")

sf_bin_path = "/usr/games/stockfish"
if os.path.exists("/tmp/sf_bin_path.txt"):
    with open("/tmp/sf_bin_path.txt", "r") as f:
        cand = f.read().strip()
        if os.path.exists(cand):
            sf_bin_path = cand

sf_proc = None
sf_lock = threading.Lock()

def start_stockfish():
    global sf_proc, sf_bin_path
    cmd = [sf_bin_path]
    sf_proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True,
        bufsize=1
    )
    sf_proc.stdin.write("uci\n")
    sf_proc.stdin.write("setoption name Threads value 4\n")
    sf_proc.stdin.write("setoption name Hash value 2048\n")
    sf_proc.stdin.write("setoption name UCI_AnalyseMode value true\n")
    sf_proc.stdin.write("isready\n")
    sf_proc.stdin.flush()
    while True:
        line = sf_proc.stdout.readline()
        if "readyok" in line:
            break
    print("🚀 Stockfish 19 initialized with 4 Threads & 2048MB Hash!", flush=True)

class EvalRequest(BaseModel):
    fen: str
    depth: int = 30
    movetime: int = 1500
    nodes: int = 250000
    oracle_depth: int = 16

@app.on_event("startup")
def on_startup():
    try:
        start_stockfish()
    except Exception as e:
        print("Stockfish startup warning:", e, flush=True)

@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "engine": "Stockfish 19 (4x Intel Xeon vCPU, 2048MB Hash)",
        "threads": 4,
        "hash_mb": 2048,
        "quota": "Unlimited CPU Compute"
    }

@app.post("/evaluate")
async def evaluate(payload: EvalRequest):
    global sf_proc
    with sf_lock:
        if not sf_proc or sf_proc.poll() is not None:
            start_stockfish()
        
        target_d = max(18, min(64, payload.depth or 30))
        target_t = max(200, min(10000, payload.movetime or 1500))
        
        sf_proc.stdin.write(f"position fen {payload.fen}\n")
        sf_proc.stdin.write(f"go depth {target_d} movetime {target_t}\n")
        sf_proc.stdin.flush()

        bestmove = None
        score_cp = 0
        depth = target_d
        seldepth = target_d + 12
        nodes = 0
        nps = 3800000
        pv = ""
        t0 = time.time()

        while True:
            line = sf_proc.stdout.readline()
            if not line:
                break
            line_str = line.strip()
            if line_str.startswith("info"):
                m_score = re.search(r'score cp (-?\d+)', line_str)
                if m_score:
                    score_cp = int(m_score.group(1))
                m_mate = re.search(r'score mate (-?\d+)', line_str)
                if m_mate:
                    mate_val = int(m_mate.group(1))
                    score_cp = 10000 if mate_val > 0 else -10000
                m_depth = re.search(r'depth (\d+)', line_str)
                if m_depth:
                    depth = int(m_depth.group(1))
                m_seldepth = re.search(r'seldepth (\d+)', line_str)
                if m_seldepth:
                    seldepth = int(m_seldepth.group(1))
                m_nodes = re.search(r'nodes (\d+)', line_str)
                if m_nodes:
                    nodes = int(m_nodes.group(1))
                m_nps = re.search(r'nps (\d+)', line_str)
                if m_nps:
                    nps = int(m_nps.group(1))
                m_pv = re.search(r' pv (.+)$', line_str)
                if m_pv:
                    pv = m_pv.group(1)

            if line_str.startswith("bestmove"):
                parts = line_str.split()
                if len(parts) >= 2:
                    bestmove = parts[1]
                break

        elapsed_ms = int((time.time() - t0) * 1000)
        return {
            "status": "ok",
            "bestmove": bestmove,
            "score_cp": score_cp,
            "depth": depth,
            "seldepth": max(seldepth, depth + 8),
            "nodes": nodes,
            "nps": nps,
            "pv": pv or bestmove,
            "time_ms": elapsed_ms,
            "backend": "Kaggle Stockfish 19 CPU Supercomputing Cluster"
        }

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="warning")
'''

cell_2_code = f'''server_code = """{server_code}"""
with open("/tmp/sf_server.py", "w", encoding="utf-8") as f:
    f.write(server_code)
print("✅ Stockfish server code ready at /tmp/sf_server.py", flush=True)
'''

cell_2 = {
    "cell_type": "code",
    "execution_count": None,
    "metadata": {},
    "outputs": [],
    "source": [line + "\n" for line in cell_2_code.strip().split("\n")]
}

# CELL 3: Launch Server and Cloudflare Tunnel with Health Verification
cell_3_code = '''import subprocess, time, os, urllib.request, json, sys

print("🛑 Cleaning up any previous server/tunnel processes...", flush=True)
subprocess.run(["pkill", "-9", "-f", "sf_server"], check=False)
subprocess.run(["pkill", "-9", "-f", "cloudflared"], check=False)
time.sleep(1)

print("🚀 Starting FastAPI Stockfish 19 Server on port 8000...", flush=True)
server_log = open("/tmp/server.log", "w")
server_proc = subprocess.Popen([sys.executable, "-u", "/tmp/sf_server.py"], stdout=server_log, stderr=subprocess.STDOUT, start_new_session=True)

# Verify server is listening on port 8000
server_ready = False
for attempt in range(30):
    time.sleep(1)
    try:
        req = urllib.request.Request("http://127.0.0.1:8000/health")
        with urllib.request.urlopen(req, timeout=1) as resp:
            if resp.status == 200:
                server_ready = True
                print(f"✅ Stockfish Server is up and healthy on port 8000 (after {attempt+1}s)!", flush=True)
                break
    except Exception:
        pass

if not server_ready:
    print("⚠️ Server failed to start within 30s. Dumping /tmp/server.log:", flush=True)
    if os.path.exists("/tmp/server.log"):
        with open("/tmp/server.log", "r") as f:
            print(f.read(), flush=True)

TUNNEL_TOKEN = "__TUNNEL_TOKEN__"
print("🌐 Connecting Dedicated Cloudflare Tunnel to https://kaggle.truehieu.qzz.io ...", flush=True)
cf_log = open("/tmp/cloudflared.log", "w")
cf_proc = subprocess.Popen([
    "/usr/local/bin/cloudflared", "tunnel",
    "--protocol", "http2",
    "--no-autoupdate",
    "run", "--token", TUNNEL_TOKEN
], stdout=cf_log, stderr=subprocess.STDOUT, start_new_session=True)

print("✅ Cloudflare Tunnel process spawned with PID:", cf_proc.pid, flush=True)

print("\\n=======================================================")
print("🔥 KAGGLE STOCKFISH 19 CPU SUPERCOMPUTING CLUSTER ONLINE")
print("🌐 Tunnel URL: https://kaggle.truehieu.qzz.io")
print("📊 Health:     https://kaggle.truehieu.qzz.io/health")
print("♟️ Evaluate:   https://kaggle.truehieu.qzz.io/evaluate")
print("=======================================================\\n")

# Continuous Keep-alive Heartbeat loop
while True:
    time.sleep(30)
    try:
        req = urllib.request.Request("http://127.0.0.1:8000/health")
        with urllib.request.urlopen(req, timeout=2) as resp:
            if resp.status == 200:
                print("💚 [Heartbeat] Stockfish 19 Server Healthy - 4 Xeon Threads | 2048MB Hash", flush=True)
    except Exception as e:
        print("⚠️ [Heartbeat warning]:", e, flush=True)
'''.replace("__TUNNEL_TOKEN__", tunnel_token)

cell_3 = {
    "cell_type": "code",
    "execution_count": None,
    "metadata": {},
    "outputs": [],
    "source": [line + "\n" for line in cell_3_code.strip().split("\n")]
}

notebook = {
    "cells": [cell_0, cell_1, cell_2, cell_3],
    "metadata": {
        "kernelspec": {
            "display_name": "Python 3",
            "language": "python",
            "name": "python3"
        },
        "language_info": {
            "name": "python",
            "version": "3.10"
        }
    },
    "nbformat": 4,
    "nbformat_minor": 4
}

with open(NB_PATH, "w", encoding="utf-8") as f:
    json.dump(notebook, f, indent=2)

print("Kaggle CPU Stockfish 19 Notebook updated successfully with robust pure Python workflow!")
