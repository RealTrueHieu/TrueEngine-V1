import os
import sys
from huggingface_hub import hf_hub_download

HF_TOKEN = "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"
REPO_ID = "TrueHieu/trueengine-v1-models"
DEST_DIR = r"C:\Users\RealTrueHieu\CustomHumanChessEngine\models"
os.makedirs(DEST_DIR, exist_ok=True)

print("=" * 60)
print("  TRUEENGINE V1 - FETCH LATEST WEIGHTS FROM HUGGING FACE")
print(f"  Source: https://huggingface.co/{REPO_ID}")
print("=" * 60)

for filename in ["trueengine_v1_best.pt", "trueengine_v1_best.onnx"]:
    try:
        print(f"⬇️ Downloading {filename}...", flush=True)
        local_path = hf_hub_download(
            repo_id=REPO_ID,
            filename=filename,
            local_dir=DEST_DIR,
            token=HF_TOKEN
        )
        size_mb = os.path.getsize(local_path) / (1024 * 1024)
        print(f"✅ Successfully downloaded {filename} ({size_mb:.2f} MB) -> {local_path}")
    except Exception as e:
        print(f"⚠️ Could not download {filename} yet ({e}). It will be available once the GPU kernel finishes.")

print("\n🎉 Fetch routine complete!")
