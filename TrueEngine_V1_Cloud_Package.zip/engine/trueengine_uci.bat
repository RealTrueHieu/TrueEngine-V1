@echo off
REM ==============================================================================
REM TrueEngine V1: En Croissant UCI Engine Launcher (Windows) - Expert Standard
REM ==============================================================================
python -u "%~dp0trueengine_uci.py" %*
