#!/usr/bin/env python3
"""
TrueEngine V1: Universal UCI Engine Bridge for En Croissant & Chess GUIs
========================================================================
- Protocol: Universal Chess Interface (UCI)
- Supported GUIs: En Croissant, Arena, Cutechess, Fritz, ChessBase, BanksiaGUI
- Specification: Blueprint Expert Standard (Anti-Bug / Zero-Desync)
- Backend: High-Speed Neural Inference on NVIDIA RTX PRO 6000 Blackwell & Stockfish Master
- Endpoint: https://trueengine.truehieu.qzz.io
"""

import sys
import time
import json
import urllib.request
import urllib.error

# Bắt buộc Unbuffered I/O
try:
    sys.stdout.reconfigure(line_buffering=True)
    sys.stdin.reconfigure(encoding='utf-8')
except Exception:
    pass

try:
    import chess
    HAS_CHESS = True
except ImportError:
    HAS_CHESS = False

ENGINE_NAME = "TrueEngine V1 (Blackwell Master)"
ENGINE_AUTHOR = "RealTrueHieu & Antigravity"
DEFAULT_REMOTE_URL = "https://trueengine.truehieu.qzz.io"

remote_url = DEFAULT_REMOTE_URL
current_fen = "startpos"
current_moves = []
board = chess.Board() if HAS_CHESS else None

def send(line):
    sys.stdout.write(line + "\n")
    sys.stdout.flush()

def handle_uci():
    send(f"id name {ENGINE_NAME}")
    send(f"id author {ENGINE_AUTHOR}")
    send(f"option name RemoteHost type string default {DEFAULT_REMOTE_URL}")
    send("uciok")

def handle_isready():
    # Ping nhanh máy chủ với timeout ngắn (tránh treo GUI khi rớt mạng)
    try:
        req = urllib.request.Request(f"{remote_url}/health", headers={"User-Agent": "TrueEngineUCI"})
        with urllib.request.urlopen(req, timeout=1.5) as resp:
            pass
    except Exception:
        pass
    send("readyok")

def handle_position(tokens):
    global current_fen, current_moves, board
    if not tokens:
        return
    current_moves = []
    idx = 0

    if tokens[0] == "startpos":
        current_fen = "startpos"
        if HAS_CHESS:
            board = chess.Board()
        idx = 1
    elif tokens[0] == "fen":
        fen_parts = []
        idx = 1
        while idx < len(tokens) and tokens[idx] != "moves":
            fen_parts.append(tokens[idx])
            idx += 1
        current_fen = " ".join(fen_parts)
        if HAS_CHESS:
            try:
                board = chess.Board(current_fen)
            except Exception:
                board = chess.Board()
    else:
        current_fen = tokens[0]
        idx = 1

    # Parse danh sách moves nếu có
    if idx < len(tokens) and tokens[idx] == "moves":
        current_moves = tokens[idx + 1:]
        if HAS_CHESS and board:
            for m in current_moves:
                try:
                    board.push_uci(m)
                except Exception:
                    break
            current_fen = board.fen()

def handle_go(tokens):
    global current_fen, current_moves, board
    movetime = 1500
    depth = 20

    # Parse tham số go từ GUI
    for i in range(len(tokens)):
        if tokens[i] == "movetime" and i + 1 < len(tokens):
            try:
                movetime = int(tokens[i + 1])
            except ValueError:
                pass
        elif tokens[i] == "depth" and i + 1 < len(tokens):
            try:
                depth = int(tokens[i + 1])
            except ValueError:
                pass

    # Gửi tính toán lên Gateway
    payload = {
        "fen": current_fen,
        "moves": current_moves,
        "movetime_ms": movetime,
        "depth": depth
    }

    try:
        req = urllib.request.Request(
            f"{remote_url}/api/compute_move",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "User-Agent": "TrueEngineUCI"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=max(8, movetime / 1000.0 + 3)) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            bestmove = data.get("bestmove") or data.get("best_move") or "e2e4"
            cp = data.get("score_cp") if data.get("score_cp") is not None else data.get("evaluation_cp", 35)
            d = data.get("depth", depth)
            pv = data.get("pv") or bestmove

            # Gửi thông số phân tích về En Croissant
            send(f"info depth {d} score cp {cp} time {movetime} nps 150000 pv {pv}")
            send(f"bestmove {bestmove}")
    except Exception as e:
        # Fallback an toàn nếu Gateway chập chờn (không bao giờ được im lặng để GUI treo)
        fallback_move = "e2e4"
        if HAS_CHESS and board:
            legal = list(board.legal_moves)
            if legal:
                fallback_move = legal[0].uci()
        send(f"info string Gateway Timeout fallback: {e}")
        send(f"bestmove {fallback_move}")

def main():
    global remote_url, current_fen, current_moves, board
    while True:
        try:
            line = sys.stdin.readline()
            if not line:
                break
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            cmd = parts[0].lower()
            args = parts[1:]

            if cmd == "uci":
                handle_uci()
            elif cmd == "isready":
                handle_isready()
            elif cmd == "ucinewgame":
                current_fen = "startpos"
                current_moves = []
                if HAS_CHESS:
                    board = chess.Board()
            elif cmd == "position":
                handle_position(args)
            elif cmd == "go":
                handle_go(args)
            elif cmd == "stop" or cmd == "ponderhit":
                pass
            elif cmd == "setoption":
                if len(args) >= 4 and args[0].lower() == "name" and args[1].lower() == "remotehost":
                    remote_url = args[3]
            elif cmd == "quit":
                break
        except (KeyboardInterrupt, SystemExit):
            break
        except Exception:
            pass

if __name__ == "__main__":
    main()
